﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace boton_movimiento
{
    public partial class Form1 : Form
    {
      

        int x, y;
        int vx = 10, vy = 13;
      
      

        public Form1()
        {
            InitializeComponent();

            
        }

        
        private void timer1_Tick(object sender, EventArgs e)
        {
            
            x = (this.Width - button1.Width) - 25;
            y = (this.Height - button1.Height) - 45;
            button1.Left = button1.Left + vx;
            button1.Top = button1.Top + vy;
            if (button1.Left > x || button1.Left <= 0)
            {
                vx = vx * -1;
            
            }
            if (button1.Top > y || button1.Top <= 0)
            {
                vy = vy * -1;
                
                
            }
        }

    }
}
